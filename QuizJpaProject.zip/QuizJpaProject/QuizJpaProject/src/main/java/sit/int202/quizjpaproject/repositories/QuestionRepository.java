package sit.int202.quizjpaproject.repositories;

import sit.int202.quizjpaproject.entities.Question;

public class QuestionRepository extends BaseRepository<Question, Long> {

}
