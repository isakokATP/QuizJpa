package sit.int202.quizjpaproject.repositories;

import sit.int202.quizjpaproject.entities.User;

public class UserRepository extends BaseRepository<User, String> {

}
