package sit.int202.quizjpaproject.repositories;

import sit.int202.quizjpaproject.entities.Answer;
import sit.int202.quizjpaproject.entities.Question;

public class AnswerRepository extends BaseRepository<Answer, Long> {

}
