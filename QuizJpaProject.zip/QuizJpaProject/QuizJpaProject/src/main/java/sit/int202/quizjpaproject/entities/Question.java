package sit.int202.quizjpaproject.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@RequiredArgsConstructor
@NoArgsConstructor
@Entity
@ToString
@Table(name = "questions")
@NamedQueries({
        @NamedQuery(name = "Question.SortByQuestion", query = "select q from Question q order by q.question desc "),
        @NamedQuery(name = "Query.SearchByQuestion", query = "select q from Question q where  q.question = :param "),
        @NamedQuery(name = "Question.QuestionsByUserName", query = "select q from Question q where q.userName = :param")
})
public class Question {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NonNull
    private String question;
    @Column(name ="username")
    private String userName;

    @OneToMany(mappedBy = "question", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private List<Answer> answers = new ArrayList<>(10);

    public void addAnswer(Answer answer){
        answers.add(answer);
    }
}
