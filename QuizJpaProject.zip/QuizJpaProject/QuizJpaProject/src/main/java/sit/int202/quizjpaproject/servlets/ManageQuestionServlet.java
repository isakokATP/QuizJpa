package sit.int202.quizjpaproject.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.quizjpaproject.entities.Answer;
import sit.int202.quizjpaproject.entities.Question;
import sit.int202.quizjpaproject.repositories.AnswerRepository;
import sit.int202.quizjpaproject.repositories.QuestionRepository;

import java.io.*;

@WebServlet(name = "ManageQuestionServlet", value = "/manage-question")
public class ManageQuestionServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);

        QuestionRepository questionRepo = new QuestionRepository();
        String strId = request.getParameter("id");
        String action = request.getParameter("action");

        if (strId.equals("new")) {
            request.getRequestDispatcher("/question.jsp").forward(request, response);
        } else if (action.equals("edit-answer")) {
                    Long longId = Long.parseLong(strId);
            Question question = questionRepo.find(longId);
            request.setAttribute("question", question);
            request.getRequestDispatcher("/question.jsp").forward(request, response);
        } else if (action.equals("remove-question")) {
            Long longId = Long.parseLong(strId);
            questionRepo.delete(longId);
            response.sendRedirect("list-questions");
        }else if (action.equals("remove-answer")) {
            AnswerRepository answerRepo = new AnswerRepository();
            String strIdx = request.getParameter("idx");
            Long longIdx = Long.parseLong(strIdx);
            Long longId = Long.parseLong(strId);
            Question question = questionRepo.find(longId);
            Answer answer = answerRepo.find(longIdx);
            question.getAnswers().remove(answer);
            if (questionRepo.update(question)){
                System.out.println("question id => " + strId);
                System.out.println("answer id => " + strIdx);
                response.sendRedirect("manage-question?id="+ strId +"&action=edit-answer");
            }
        } else {
            Long longId = Long.parseLong(strId);
            Question question = questionRepo.find(longId);
            if (question != null){
                Cookie lastQuestion = new Cookie("lastquestion", "manage-question?id=" + longId);
                lastQuestion.setMaxAge(7*24*60*60);
                response.addCookie(lastQuestion);
                request.setAttribute("question", question);
                getServletContext().getRequestDispatcher("/question.jsp").forward(request, response);
                return;
            }
        }
        response.sendRedirect("/list-questions");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        QuestionRepository questionRepo = new QuestionRepository();
        AnswerRepository answerRepo = new AnswerRepository();
        String strId = request.getParameter("id");
        String strQuestion = request.getParameter("text");
        String correct = request.getParameter("isCorrect");
        String action = request.getParameter("action");
        int isCorrect;
        if (correct != null){
            isCorrect = 1;
        } else {
            isCorrect = 0;
        }

        if (action.equals("new-question")){
            Question question = new Question();
            questionRepo.save(question);
            response.sendRedirect("manage-question?id=" + question.getId() + "&action=edit-answer");
        } else if (action.equals("new-answer")) {
            Long longId = Long.parseLong(strId);
            Answer answer = new Answer(strQuestion, isCorrect);
            Question question = questionRepo.find(longId);
            answer.setQuestion(question);
            question.addAnswer(answer);
            if (questionRepo.update(question)){
                response.sendRedirect("manage-question?id" + strId + "&action=edit-answer");
            }
        } else if (action.equals("edit-answer")) {
            Long longId = Long.parseLong(strId);
            String strIdx = request.getParameter("idx");
            Long longIdx = Long.parseLong(strIdx);
            Answer answer = answerRepo.find(longIdx);
            answer.setAnswer(strQuestion);
            answer.setIsCorrect(isCorrect);
            if (answerRepo.update(answer)){
                response.sendRedirect("manage-question?id=" + strId + "&action=edit-answer");
            }

        } else if (action.equals("edit-question")) {
            Long longId = Long.parseLong(strId);
            Question question = questionRepo.find(longId);
            question.setQuestion(strQuestion);

            if (questionRepo.update(question)){
                response.sendRedirect("manage-question?id=" + strId + "&action=edit-answer");
            }
        } else {
            System.out.println("There is something wrong for creating the question!");
        }
    }
}