package sit.int202.quizjpaproject;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;
import sit.int202.quizjpaproject.entities.Answer;
import sit.int202.quizjpaproject.entities.Question;
import sit.int202.quizjpaproject.entities.User;
import sit.int202.quizjpaproject.repositories.QuestionRepository;
import sit.int202.quizjpaproject.repositories.UserRepository;

import javax.security.auth.login.AccountNotFoundException;
import java.util.List;

public class TestQuizJpa {
    public static void main(String[] args) {
//        testQuiz();
//        testQuizRepo();
//        testQuizAdd();
//        testQuizBaseRepository();
    }
    public static void testUserRepository(){
        UserRepository userRepo = new UserRepository();
        List<User> users = userRepo.findAll();
        for (User user: users){
            System.out.println(user);
        }
    }

    public static void testQuiz(){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
        EntityManager em = emf.createEntityManager();
        Question question = em.find(Question.class, 1);
        System.out.println(question);
    }

    public static void testQuizRepo(){
        QuestionRepository questionRepo =  new QuestionRepository();
        Question question = questionRepo.find(1L);
        System.out.println(question);
    }

    public static void  testQuizAdd(){
        QuestionRepository questionRepo = new QuestionRepository();
        Question question = new Question("5!");
        Answer answer = new Answer("24", 0);
        answer.setQuestion(question);
        question.addAnswer(answer);
        answer = new Answer("120", 1);
        answer.setQuestion(question);
        question.addAnswer(answer);
        answer = new Answer("720", 0);
        answer.setQuestion(question);
        question.addAnswer(answer);
        if (questionRepo.save(question)){
            System.out.println("Question is created succesfully!");
        } else {
            System.out.println("There is something wrong for creating the question!");
        }
    }

    public static void testQuizBaseRepository(){
        QuestionRepository questionRepository = new QuestionRepository();

        int countRows = questionRepository.countRows();
        System.out.println("---------------Question Rows--------------");
        System.out.println("# question rows = " + countRows);

//        List<Question> questions = questionRepository.getResultListFromNamedQuery("Question.SortByQuestion");
        List<Question> questions = questionRepository.findAll() ;
        System.out.println("----------Sort By Question--------");
        for (Question question: questions){
            System.out.println(question);
        }
    }
}
